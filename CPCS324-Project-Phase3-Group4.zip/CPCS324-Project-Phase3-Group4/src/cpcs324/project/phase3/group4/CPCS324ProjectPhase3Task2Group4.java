package cpcs324.project.phase3.group4;

// Group 4: 
// Ethar Nasser Alahmari 1807758
// Rahaf Ibrahim Braiji 1805651
// Sara Abdulilah Alhaifi 1807468

import java.util.*;
import java.lang.*;
import java.io.*;

public class CPCS324ProjectPhase3Task2Group4 {

    // M is number of applicants
    // and N is number of Hospitals
    static final int M = 6;
    static final int N = 6;
    static int matchR[] = new int[N];
    
    /**
     * 
     * @param args
     * @throws java.lang.Exception 
     */
    
    public static void main(String[] args) throws java.lang.Exception {
        System.out.println("-------------- CPCS324 Project - Phase3 - Task2 - Group4 --------------\n");
        
        boolean bpGraph[][] = new boolean[][]{
            {true, true, false, false, false, false},
            {false, false, false, false, false, true},
            {true, false, false, true, false, false},
            {false, false, true, false, false, false},
            {false, false, false, true, true, false},
            {false, false, false, false, false, true}};
        
        /**
         * 
         * hospitals: Array to store hospitals names
         * applicants: Array to store applicants names
         */
        String hospitals [] = 
            {"King Abdelaziz University", 
            "King Fahd", 
            "East Jeddah", 
            "King Fahad Armed Forces", 
            "King Faisal Specialist", 
            "Ministry of National Guard"};
        
        String applicants [] = 
            {"Ahme", 
            "Mahmoud", 
            "Ema", 
            "Fatimah", 
            "Kamel", 
            "Nojoo"};
        
        boolean appointed [] = new boolean [N];
        for (int k = 0; k < appointed.length; k++) {
            appointed[k]=false;
        }
        
        int result = maxBPM(bpGraph);
        for (int i = 0; i < N; i++) {
            if (matchR[i] > -1) {
                System.out.println(applicants[matchR[i]] + "\t   Appointed by    " + hospitals[i] + " Hospital");
                appointed[matchR[i]]=true;
            } 
        }
        
        System.out.println("");
        
        for (int j = 0; j < N; j++) {
            if (appointed[j] == false) {
                System.out.println(applicants[j] + " does not appointed by any hospital");
            } 
            if (matchR[j] == -1){
                System.out.println(hospitals[j] + " does not appoint any applicant");
            }
        }
        
        System.out.println("\nMaximum number of applicants that can get a position in hospital are " + result);

    }
    
    
    /**
     * 
     * @param bpGraph: Create a maximum bipartite matching graph that given in project( Hospitals, Applicants )
     * @return maximum number of matching from applicants to hospitals
     */
    
    static int maxBPM(boolean bpGraph[][]) {
            // An array to keep track of the 
            // applicants assigned to hospitals. 
            // The value of matchR[i] is the 
            // applicant number assigned to hospital i, 
            // the value -1 indicates nobody is assigned.

            // Initially all hospital are available
            for (int i = 0; i < N; ++i) {
                matchR[i] = -1;
            }

            // Count of hospital appointed applicants
            int result = 0;
            for (int u = 0; u < M; u++) {
                // Mark all hospitals as not seen for next applicant.
                boolean seen[] = new boolean[N];
                for (int i = 0; i < N; ++i) {
                    seen[i] = false;
                }

                // Find if the applicant 'u' can appoint 
                if (bipartiteMatching(bpGraph, u, seen, matchR)) {
                    result++;
                }
            }
            return result;
        }

    /**
     * 
     * @param bpGraph : maximum bipartite matching graph that given in project( Hospitals, Applicants )
     * @param u : the applicant
     * @param seen : array of hospitals, filled with true value if the hospital position is unavailable, false value if the hospital position is available
     * @param matchR : array of appointed applicant with their hospitals
     * @return true if the hospital position is appointed to an applicant, false value if the hospital position is free
     */
    static boolean bipartiteMatching (boolean bpGraph[][], int u, boolean seen[], int matchR[]) {
            // Try every hospital one by one
            for (int v = 0; v < N; v++) {
                // If applicant u is interested in hospital v and v is not visited
                if (bpGraph[u][v] && !seen[v]) {

                    // Mark v as visited
                    seen[v] = true;

                    // If hospital 'v' is not assigned to
                    // an applicant OR previously
                    // assigned applicant for hospital v (which
                    // is matchR[v]) has an alternate job available.
                    // Since v is marked as visited in the 
                    // above line, matchR[v] in the following
                    // recursive call will not get hospital 'v' again
                    if (matchR[v] < 0 || bipartiteMatching(bpGraph, matchR[v],seen, matchR)) {
                        matchR[v] = u;
                        return true;
                    }
                }
            }
            return false;
        }

    }
